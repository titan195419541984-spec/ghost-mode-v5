
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body style={{margin:0, background:'#0A0A0A'}}>{children}</body></html>);
}
